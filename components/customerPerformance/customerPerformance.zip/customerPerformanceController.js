﻿appModule.controller("customerPerformanceController", [
  '$rootScope', '$scope', '$agentService', '$compile', '$rootScope', 'DTOptionsBuilder', 'DTColumnDefBuilder', '$timeout', function ($rootScope, $scope, $agentService, $compile, $rootScope, DTOptionsBuilder, DTColumnDefBuilder, $timeout) {
    let tableData = [];

    $scope.Filters = {
      Sports: [],
      Periods: [],
      WagerTypes: [],
      WagersWithSameLeagueOnly: true,
      ParlaySports: [],
      TeaserSports: []
    };

    async function Init() {
      $scope.WeeksRange = $agentService.GetWeeksRange();
      $scope.selectedWeek = $scope.WeeksRange[0];
      if ($rootScope.selectedAgent) {
        $scope.getData();
      } else {
        $rootScope.$on('AgentAsCustomerInfoReady', function () {
          $scope.selectedAgent = $scope.AllAgentsList ? $scope.AllAgentsList[0] : null;
          $scope.getData();
        });
      }
    };

    var _wagerTypes = [
      {
        Name: "All",
        Code: "All",
        Selected: true,
        Index: 0
      }, {
        Name: "Spread",
        Code: "S",
        Selected: true,
        Index: 1
      }, {
        Name: "Money Line",
        Code: "M",
        Selected: true,
        Index: 2
      }, {
        Name: "Total Points",
        Code: "L",
        Selected: true,
        Index: 3
      }, {
        Name: "Team Totals",
        Code: "E",
        Selected: true,
        Index: 4
      }, {
        Name: "Parlay",
        Code: "P",
        Selected: true,
        Index: 5
      }, {
        Name: "Teaser",
        Code: "T",
        Selected: true,
        Index: 6
      }, {
        Name: "If Bet",
        Code: "I",
        Selected: true,
        ArLink: false,
        Index: 7
      }, {
        Name: "Action Reverse",
        Code: "I",
        Selected: true,
        ArLink: true,
        Index: 8
      }, {
        Name: "Contest",
        Code: "C",
        Selected: true,
        Index: 9
      }, {
        Name: "Manual Play",
        Code: "A",
        Selected: true,
        Index: 10
      }, {
        Name: "Horses",
        Code: "G",
        Selected: true,
        Index: 11
      }
    ];

    $scope.betTypeList = [{ name: $scope.Translate('Wager'), code: 0 }, { name: $scope.Translate('Future'), code: 1 }];
    $scope.SelectedBetType = $scope.betTypeList[0];

    function setFiltersInfo(data) {
      var sports = [];
      var periods = [];
      var wagerTypes = [];
      var customers = [];
      var parlaySports = [];
      var teaserSports = [];
      var d, s, p, wt, c, ps, ts;
      for (var i = 0; i < data.length; i++) {
        d = data[i];
        if (!d.SportType || !d.SportSubType) continue;
        //Sports
        s = sports.find(e => e && e.SportType == (d.SportType || "").trim() && e.SportSubType == (d.SportSubType || "").trim());
        if (!s) sports.push({ SportType: (d.SportType || "").trim(), SportSubType: (d.SportSubType || "").trim(), FullName: (d.SportType || "").trim() + ' - ' + (d.SportSubType || "").trim(), Selected: false });

        //Sports Parlays
        if (d.WagerType == "P") {
          s = parlaySports.find(e => e && e.SportType == (d.SportType || "").trim() && e.SportSubType == (d.SportSubType || "").trim());
          if (!s) parlaySports.push({ SportType: (d.SportType || "").trim(), SportSubType: (d.SportSubType || "").trim(), FullName: (d.SportType || "").trim() + ' - ' + (d.SportSubType || "").trim(), Selected: true });
        }

        //Sports Teasers
        if (d.WagerType == "T") {
          s = teaserSports.find(e => e && e.SportType == (d.SportType || "").trim() && e.SportSubType == (d.SportSubType || "").trim());
          if (!s) teaserSports.push({ SportType: (d.SportType || "").trim(), SportSubType: (d.SportSubType || "").trim(), FullName: (d.SportType || "").trim() + ' - ' + (d.SportSubType || "").trim(), Selected: true });
        }

        //Periods
        p = periods.find(e => e && e.PeriodDescription == d.PeriodDescription.trim());
        if (!p) periods.push({ PeriodDescription: d.PeriodDescription.trim(), Selected: true });

        wt = wagerTypes.find(e => e && e.Code == d.WagerType.trim() && ((!e.ArLink && !d.ArLink) || (e.ArLink && d.ArLink)));
        if (!wt) {
          wagerTypes.push(_wagerTypes.find(e => e && e.Code == d.WagerType.trim() && ((!e.ArLink && !d.ArLink) || (e.ArLink && d.ArLink))));
        }

        c = customers.find(e => e && e.CustomerId == d.CustomerId.trim());
        if (!c) customers.push({ CustomerId: d.CustomerId.trim(), Selected: false });

      }
      sports.splice(0, 0, { SportType: "All", SportSubType: "All", FullName: "All" });

      let wagersWithSameLeagueOnly = $scope.Filters.WagersWithSameLeagueOnly;
      $scope.Filters = {
        Sports: sports,
        ParlaySports: parlaySports,
        TeaserSports: teaserSports,
        Periods: periods,
        WagerTypes: wagerTypes,
        Customers: customers,
        WagersWithSameLeagueOnly: wagersWithSameLeagueOnly
      };
      retrieveSelectedFilters();

    }

    function setInitialSelectedFilters() {
      if ($scope.Filters.Sports && $scope.Filters.Sports.length)
        $scope.Filters.Sports[0].Selected = true;
      if ($scope.Filters.Periods && $scope.Filters.Periods.length)
        $scope.Filters.Periods[0].Selected = true;
      if ($scope.Filters.WagerTypes && $scope.Filters.WagerTypes.length)
        $scope.Filters.WagerTypes[0].Selected = true;
      if ($scope.Filters.Clients && $scope.Filters.Clients.length)
        $scope.SelectedCustomer = $scope.Filters.Clients[0];
    }

    function applyRowFilter(row, allSports) {
      let p = $scope.Filters.Periods.find(e => (e.PeriodDescription || "").trim() == (row.PeriodDescription || "").trim() && e.Selected);
      if (!p) return null;
      p = $scope.Filters.WagerTypes.find(e => e.Code == row.WagerType && e.Selected);
      if (!p) return null;
      if (!allSports) {
        p = $scope.Filters.Sports.find(e => e.SportType == row.SportType && e.SportSubType == row.SportSubType && e.Selected);
        if (!p) return null;
      }

      if ($scope.Filters.WagersWithSameLeagueOnly) {
        let spts = tableData.filter(e => e.TicketNumber == row.TicketNumber && e.WagerNumber == row.WagerNumber);
        if (spts && spts.length) {
          let sameSpts = spts.filter(e => e.SportType == row.SportType && e.SportSubType == row.SportSubType);
          if (spts.length != sameSpts.length)  return null;
        }
      }

      return row;
    }

    function refreshTableView() {
      storeFilters();
      if (!tableData) return;
      let result = [];
      let sports = $scope.Filters.Sports.filter(e => e.Selected);
      let parlaySports = $scope.Filters.ParlaySports.filter(e => e.Selected);
      let teaserSports = $scope.Filters.TeaserSports.filter(e => e.Selected);
      let allSportsSelected = $scope.Filters.Sports[0].Selected;
      tableData.forEach(function (row) {

        let r = applyRowFilter(row, allSportsSelected);
        if (!r) return;

        var customerRow = result.find(e => e.CustomerId == row.CustomerId);
        if (!customerRow) {
          customerRow = {
            CustomerId: row.CustomerId,
            SportsInfo: new Array(sports.length + 3).fill(0)
          };
          result.push(customerRow);
        }
        var sportIdx = sports.indexOf(sports.find(e => e.SportSubType == row.SportSubType || (e.SportSubType == "All" && allSportsSelected)));
        if (sportIdx >= 0) {
          customerRow.SportsInfo[sportIdx] += row.Volume;
          customerRow.SportsInfo[sports.length + 2] += row.Volume;
        }
        if (row.WagerType == "P") {
          sportIdx = parlaySports.indexOf(parlaySports.find(e => e.SportSubType == row.SportSubType));
          if (sportIdx >= 0) customerRow.SportsInfo[sports.length] += row.Volume;
        }
        if (row.WagerType == "T") {
          sportIdx = teaserSports.indexOf(teaserSports.find(e => e.SportSubType == row.SportSubType));
          if (sportIdx >= 0) customerRow.SportsInfo[sports.length + 1] += row.Volume;
        }

      });

      $scope.VolumeReportInfo = result;

    }

    $scope.FilterSports = function (sp) {
      return !sp.Hidden;
    };

    $scope.OnFilterChange = function (sportChanged) {
      if (sportChanged) {
        if (sportChanged.Selected && sportChanged.SportType == "All") {
          $scope.Filters.Sports.forEach(function (sport) {
            if (sport.SportType == "All") return;
            sport.Selected = !$scope.Filters.Sports[0].Selected;
          });
        } else if (sportChanged.SportType != "All") {
          $scope.Filters.Sports[0].Selected = false;
        }
      }
      refreshTableView();
    };

    function storeFilters() {
      var filters = {
        Sports: $scope.Filters.Sports.filter(s => s.Selected),
        Periods: $scope.Filters.Periods.filter(s => s.Selected),
        WagerTypes: $scope.Filters.WagerTypes.filter(s => s && s.Selected)
      };
      $scope.addSessionData("customerPerformanceFilters", filters);
    }

    function retrieveSelectedFilters() {
      var filters = $scope.getSessionData("customerPerformanceFilters");
      if (!filters) {
        setInitialSelectedFilters();
        return;
      }
      if (filters.Sports && $scope.Filters.Sports && filters.Sports.length)
        filters.Sports.forEach(function (sf) {
          var s = $scope.Filters.Sports.find(e => e.SportType == sf.SportType && e.SportSubType == sf.SportSubType);
          if (s) s.Selected = true;
        });
      else $scope.Filters.Sports[0].Selected = true;
      if (filters.Periods && $scope.Filters.Periods && filters.Periods.length)
        filters.Periods.forEach(function (pf) {
          var p = $scope.Filters.Periods.find(e => e.PeriodDescription == pf.PeriodDescription);
          if (p) p.Selected = true;
        });
      if (filters.WagerTypes && $scope.Filters.WagerTypes && filters.WagerTypes.length)
        filters.WagerTypes.forEach(function (wtf) {
          var wt = $scope.Filters.WagerTypes.find(e => e.Code == wtf.Code);
          if (wt) wt.Selected = true;
        });
    }

    $scope.getData = function () {
      tableData = [];
      let params = {
        agentId: $rootScope.selectedAgent ? $rootScope.selectedAgent.AgentId : $scope.AgentAsCustomerInfo.CustomerID,
        weekNum: $scope.selectedWeek.Index,
        betType: $scope.SelectedBetType.code
      };
      $agentService.GetCustomerPerformance(params).then(function (response) {
        tableData = response.data.d.Data;
        let groupedData = CommonFunctions.groupBy(tableData, 'SportType');

        setFiltersInfo(tableData);

        $scope.Filters.Clients = [{ CustomerId: 'All' }, ...(Object.keys(groupedData).map((key) => groupedData[key])).map(x => x[0])];

        $scope.SelectedSport = $scope.Filters.Sports[0];
        groupedData = CommonFunctions.groupBy(tableData, 'SportSubType');
        $scope.Filters.Leagues = [...(Object.keys(groupedData).map((key) => groupedData[key])).map(x => x[0]).filter(x => x.SportType == $scope.Filters.Sports[1].SportSubType)];

        refreshTableView();
      });
    }

    $scope.ExportData = function () {
      Swal.fire({
        title: "Processing...",
        text: "Please wait",
        showConfirmButton: false,
        allowOutsideClick: false
      });
      const fileName = 'Volume';
      const exportType = 'xls';
      //console.log($scope.Filters.Sports, $scope.VolumeReportInfo);
      let exportData = [];
      $scope.VolumeReportInfo.forEach(function (row) {
        var info = {
          CustomerId: row.CustomerId
        };
        for (var i = 0; i < row.SportsInfo.length - 3; i++) {
          const sport = $scope.Filters.Sports[i];
          if (!sport.Selected) continue;
          const sportData = row.SportsInfo[i];
          info[sport.FullName] = CommonFunctions.FormatNumber(sportData, true);
        }
        info["Parlays"] = CommonFunctions.FormatNumber(row.SportsInfo[row.SportsInfo.length - 3], true);
        info["Teasers"] = CommonFunctions.FormatNumber(row.SportsInfo[row.SportsInfo.length - 2], true);
        info["Total"] = CommonFunctions.FormatNumber(row.SportsInfo[row.SportsInfo.length - 1], true);
        exportData.push(info);
      });
      window.exportFromJSON({ data: exportData, fileName, exportType });
      Swal.fire(
        $scope.Translate('Data exported'),
        '',
        'success'
      );
    }

    Init();
  }
]);
